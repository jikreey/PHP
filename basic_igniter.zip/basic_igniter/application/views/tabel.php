<html>
<head>
<title>Data Mahasiswa</title>
</head>

<body>
	<table border=1 style="border-collapse:collapse; width:30%;">
		<tr style="background-color: gray;">
			<th>NIM</th>
			<th>Nama</th>
			<th>Jurusan</th>
		</tr>
		<?php foreach($data as $d){ ?>
		<tr>
			<td><?php echo $d['nim']; ?></td>
			<td><?php echo $d['nama']; ?></td>
			<td><?php echo $d['jurusan']; ?></td>
		</tr>
		<?php } ?>
	</table>
</body>
</html>