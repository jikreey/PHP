<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Models extends CI_Model {
	public function Getmahasiswa(){
		$data = $this->db->query('select * from mahasiswa');
		return $data->result_array();
	}

	public function insertdata($tableName,$data){
		$result = $this->db->insert($tableName,$data);
		return $result;
	}

	public function deletedata($tableName,$where){
		$result = $this->db->delete($tableName,$where);
		return $result;
	}

	public function updatedata($tableName,$data,$where){
		$result = $this->db->update($tableName,$data,$where);
		return $result;
	}
}
