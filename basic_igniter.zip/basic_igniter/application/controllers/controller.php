<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller extends CI_Controller {
	public function index()
	{
		$data = $this->models->Getmahasiswa();
		$this->load->view('tabel', array('data' => $data));
	}

	public function insert(){
		$result = $this->models->insertdata('mahasiswa',array(
			'nim' => '13789',
			'nama' => 'anasir yusuf',
			'jurusan' => 'elins'
			));

		if($result>=1){
			echo "<h2>Data Insert Sukses</h2>";
		}
	}

	public function delete(){
		$result = $this->models->deletedata('mahasiswa',array(
			'id' => '3'
			));

		if($result>=1){
			echo "<h2>Data Delet eSukses</h2>";
		}
	}

	public function update(){
		$result = $this->models->updatedata('mahasiswa',array(
			'nim' => '13649',
			),array(
			'id' => '3'
			));

		if($result>=1){
			echo "<h2>Data Update Sukses</h2>";
		}
	}
}
